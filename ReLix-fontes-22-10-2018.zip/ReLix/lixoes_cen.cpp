#include "lixoes_cen.h"
#include "ui_lixoes_cen.h"
#include "globais.h"
#include "lixoes_cen_cad.h"
#include "lixoes_cad.h"
#include <QMessageBox>
#include <QtSql>
#include <QProgressDialog>
#include <QPainter>
#include "lixoes_cad.h"

#include <typeinfo>
# include <iostream>
using namespace std;

int _IDitem = 0;

lixoes_cen::lixoes_cen(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::lixoes_cen)
{
    ui->setupUi(this);

    // http://pt.stackoverflow.com/questions/179480/ajuda-com-signal-and-slots-conectar-em-slot-de-outro-arquivo
    //connect(ui->pbSalvar, &QPushButton::clicked, static_cast<lixoes_cad*>(parent), &lixoes_cad::atualizar_tvCenario); // ao clicar no botão salvar
    connect(this, &QDialog::rejected, static_cast<lixoes_cad*>(parent), &lixoes_cad::atualizar_tvTecnica); // ao sair do formulario

    ui->leTecnica->setReadOnly(true);
    ui->pbRemover->setEnabled(false);
    ui->tvItens->setItemDelegate(new delega_disponibilidade);

    recuperar_registro();
}

lixoes_cen::~lixoes_cen()
{
    delete ui;
}

void delega_disponibilidade::paint(QPainter *painter, const QStyleOptionViewItem &option,
                                   const QModelIndex &index) const
{
    if (index.column() == 9) // coluna que será pintada
    {
        QVariant disponibilidade = index.data();

        if (disponibilidade == "Disponível")
            painter->fillRect(option.rect, QColor(170, 216, 0));
        else if (disponibilidade == "Parcialmente disponível")
            painter->fillRect(option.rect, QColor(254, 251, 24));
        else if (disponibilidade == "Indisponível")
            painter->fillRect(option.rect, QColor(255, 40, 0));
    }

    return QItemDelegate::paint(painter, option, index);
}

void lixoes_cen::atualizar_tvItens()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    // recupera os ítens do cenário
    QString filtro;
    filtro.append("id_tecnica = "+ QString::number(_IDtec));

    QSqlRelationalTableModel *model = new QSqlRelationalTableModel(this, con);
    model->setTable("lixoes_cenarios_tecnicas_itens");
    model->setJoinMode(QSqlRelationalTableModel::LeftJoin);
    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(2, Qt::Horizontal, tr("Descrição"));
    model->setHeaderData(3, Qt::Horizontal, tr("Categoria"));
    model->setRelation(4, QSqlRelation("fornecedores", "id", "fornecedor"));
    model->setHeaderData(4, Qt::Horizontal, tr("Fornecedor"));
    model->setHeaderData(5, Qt::Horizontal, tr("Quantidade/tempo"));
    model->setHeaderData(6, Qt::Horizontal, tr("Unidade"));
    model->setHeaderData(7, Qt::Horizontal, tr("Valor unitário (R$)"));
    model->setHeaderData(8, Qt::Horizontal, tr("Valor total do ítem (R$)"));
    model->setHeaderData(9, Qt::Horizontal, tr("Disponibilidade")); // disponível, parcialmente dispoível, indisponível
    model->setFilter(filtro);
    model->setSort(0, Qt::AscendingOrder);
    model->select();

    ui->tvItens->setModel(model);
    ui->tvItens->setColumnHidden(1,true);
    ui->tvItens->setColumnHidden(10,true);
    ui->tvItens->horizontalHeader()->setSectionResizeMode(2,QHeaderView::Stretch);

    int row_count = model->rowCount();
    int soma = 0;

    for (int i=0;i<=row_count;i++)
    {
        QString vt = model->record(i).value("valor_total").toString();
        int valot_total = vt.replace(".","").replace(",","").toInt();
        soma = soma + valot_total;
    }

    // Converter para o formato brasileiro
    QLocale loc = QLocale::system();
    QLocale brasil(QLocale::Portuguese);
    loc.setNumberOptions(brasil.numberOptions());
    QLocale::setDefault(loc);

    ui->lbValorTotal->setText("<span style='font-size:9pt;'><p align='right'><b>Valor total da técnica: </b> R$"+brasil.toString(soma * 0.01, 'f', 2)+"</p></span>");


    QSqlQuery query1;
    query1.prepare("UPDATE lixoes_cenarios_tecnicas SET valor = ? WHERE id = ?");
    query1.bindValue(0,brasil.toString(soma * 0.01, 'f', 2));
    query1.bindValue(1,_IDtec);
    query1.exec();

    con.close();
}

void lixoes_cen::recuperar_registro()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("SELECT * FROM lixoes_cenarios_tecnicas WHERE id = ?");
    query.bindValue(0,_IDtec);
    query.exec();
    query.first();

    ui->leTecnica->setText(query.value("tecnica").toString());
    ui->leDescricao->setText(query.value("descricao").toString());
    ui->lbValorTotal->setText("<span style='font-size:9pt;'><p align='right'><b>Valor total: R$ </b>"+query.value("valor").toString()+"</p></span>");

    con.close();

    atualizar_tvItens();
}

void lixoes_cen::inserir()
{
    // Não existe inserir neste formulário, pois a técnica e inserida automticamente pelo sistema.
    // Esta função pode ser implementada no futuro, permitindo ao usuário inserir novas técnicas de recuperação no sistema.

    /*
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("INSERT INTO lixoes_cenarios_tecnicas (id_cenario,tecnica, descricao) VALUES (?,?,?)");
    query.bindValue(0,_ID);
    query.bindValue(1,ui->leTecnica->text());
    query.bindValue(2,ui->leDescricao->text());
    query.exec();

    con.close();

    atualizar_tvItens();

    QMessageBox msgBox;
    msgBox.setText("Informações inseridas com sucesso");
    msgBox.exec();
    */
}

void lixoes_cen::editar()
{

    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("UPDATE lixoes_cenarios_tecnicas SET tecnica=?, descricao=? WHERE id = ?");
    query.bindValue(0,ui->leTecnica->text()); // leTecnica será readonly, para manter o nome da técnica padronizada com o nome fornecido pelo sistema
    query.bindValue(1,ui->leDescricao->text());
    query.bindValue(2,_IDtec);
    query.exec();

    con.close();

    atualizar_tvItens();

    QMessageBox msgBox;
    msgBox.setText("Informações atualizadas com sucesso");
    msgBox.exec();

}

void lixoes_cen::on_pbSalvar_clicked()
{
    if (_IDtec == 0)
        inserir();
    else
        editar();
}

void lixoes_cen::on_pbCancelar_clicked()
{
    close();
}

void lixoes_cen::on_pbAdicionar_clicked()
{
    _IDitem = 0;

    lixoes_cen_cad *item = new lixoes_cen_cad(this);
    item->show();
}

void lixoes_cen::on_pbRemover_clicked()
{
    QMessageBox msg;
    msg.setIcon(QMessageBox::Information);
    msg.setWindowTitle("Atenção");
    msg.setTextFormat(Qt::RichText);
    msg.setText("Deseja remover definitivamente este ítem?");
    msg.setStandardButtons(QMessageBox::Yes|QMessageBox::No);
    msg.setDefaultButton(QMessageBox::No);
    int ret = msg.exec();

    switch (ret)
    {
    case QMessageBox::Yes:
    {
        QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
        con.setDatabaseName(_DB);
        con.open();

        QSqlQuery query;
        query.prepare("DELETE FROM lixoes_cenarios_tecnicas_itens WHERE id = ?");
        query.bindValue(0,_IDitem);
        query.exec();

        con.close();

        atualizar_tvItens();
        break;
    }
    case QMessageBox::No:
        break;
    }

}

void lixoes_cen::on_tvItens_clicked(const QModelIndex &index)
{
    QItemSelectionModel *model = ui->tvItens->selectionModel();
    QModelIndex current = model->currentIndex().sibling(model->currentIndex().row(),0);
    QModelIndexList selected = model->selectedIndexes();

    _IDitem = current.data().toInt();

    ui->pbRemover->setEnabled(true);
}

void lixoes_cen::on_tvItens_doubleClicked(const QModelIndex &index)
{
    QItemSelectionModel *model = ui->tvItens->selectionModel();
    QModelIndex current = model->currentIndex().sibling(model->currentIndex().row(),0);
    QModelIndexList selected = model->selectedIndexes();

    _IDitem = current.data().toInt();

    lixoes_cen_cad *item = new lixoes_cen_cad(this);
    item->show();
}
