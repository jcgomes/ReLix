#ifndef FORNECEDORES_CAD_H
#define FORNECEDORES_CAD_H

#include <QDialog>

namespace Ui {
class fornecedores_cad;
}

class fornecedores_cad : public QDialog
{
    Q_OBJECT

public:
    explicit fornecedores_cad(QWidget *parent = 0);
    ~fornecedores_cad();

private slots:
    void on_pbSalvar_clicked();

    void on_pbCancelar_clicked();

    void inserir();

    void editar();

    void recuperar_registro();

private:
    Ui::fornecedores_cad *ui;
};

#endif // FORNECEDORES_CAD_H
