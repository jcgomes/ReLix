#ifndef MUNICIPIOS_H
#define MUNICIPIOS_H

#include <QDialog>
#include <QItemDelegate>

namespace Ui {
class municipios;
}

class municipios : public QDialog
{
    Q_OBJECT

public:
    explicit municipios(QWidget *parent = 0);
    ~municipios();

public slots:
    void atualizar_db();

private slots:
    void on_tvConsulta_doubleClicked(const QModelIndex &index);

    void on_leParametro_returnPressed();

    void on_leParametro_textChanged(const QString &arg1);

    void on_pbAdicionar_clicked();

    void on_pbSair_clicked();

    void buscar();

    void on_pbAtualizar_clicked();

private:
    Ui::municipios *ui;
};
class delega_orcamento_disponivel : public QItemDelegate
{
    Q_OBJECT
public:
    delega_orcamento_disponivel(QWidget *parent = 0) : QItemDelegate(parent) {}
    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const;
};

#endif // MUNICIPIOS_H
