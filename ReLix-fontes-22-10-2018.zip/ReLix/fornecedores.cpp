#include "fornecedores.h"
#include "ui_fornecedores.h"
#include "fornecedores_cad.h"
#include "globais.h"
#include <QtSql>
#include <QHash>
#include <QDesktopWidget>

fornecedores::fornecedores(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::fornecedores)
{
    ui->setupUi(this);

    ui->pbAtualizar->setVisible(false);

    _cbCampo.clear();

    // Combobox dinâmico: http://www.qtcentre.org/threads/63124-Qcombobox-dinamically
    _cbCampo["ID"] = "fornecedores.id";
    _cbCampo["Fornecedor"] = "fornecedores.fornecedor";
    _cbCampo["Telefone"] = "fornecedores.telefone";
    _cbCampo["E-mail"] = "fornecedores.email";
    _cbCampo["Contato"] = "fornecedores.contato";

    atualizar_db();
}

fornecedores::~fornecedores()
{
    delete ui;
}

void fornecedores::on_tvConsulta_doubleClicked(const QModelIndex &index)
{
    //http://www.qtcentre.org/threads/38184-QAbstractItemModel-double-click-on-current-row
    QItemSelectionModel *model = ui->tvConsulta->selectionModel();
    QModelIndex current = model->currentIndex().sibling(model->currentIndex().row(),0);
    QModelIndexList selected = model->selectedIndexes();

    _ID = current.data().toInt();

    fornecedores_cad *cad = new fornecedores_cad(this);
    cad->show();
}

void fornecedores::on_leParametro_returnPressed()
{
    _ID = ui->tvConsulta->model()->index(0,0).data().toInt();

    fornecedores_cad *cad = new fornecedores_cad(this);
    Qt::WindowFlags flags = windowFlags(); // http://stackoverflow.com/questions/19097323/setwindowflagsqtwindowstaysontophint-hides-qt-window
    cad->setWindowFlags(flags | Qt::WindowStaysOnTopHint);
    cad->setGeometry(QStyle::alignedRect(Qt::LeftToRight,Qt::AlignCenter, cad->size(), qApp->desktop()->availableGeometry())); // centraliza
    cad->show();
}

void fornecedores::on_leParametro_textChanged(const QString &arg1)
{
    buscar();
}

void fornecedores::on_pbAdicionar_clicked()
{
    _ID = 0;
    fornecedores_cad *cad = new fornecedores_cad(this);
    cad->show();
}

void fornecedores::on_pbSair_clicked()
{
    close();
}

void fornecedores::atualizar_db()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    ui->cbCampo->clear();

    QHashIterator<QString, QString> i(_cbCampo);
    while (i.hasNext()) {
        i.next();
        ui->cbCampo->addItem(i.key());
    }

    ui->cbCampo->setCurrentText("Fornecedor");

    QSqlTableModel *model = new QSqlTableModel(this, con);
    model->setTable("fornecedores");
    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, tr("Fornecedor"));
    model->setHeaderData(2, Qt::Horizontal, tr("Telefone"));
    model->setHeaderData(3, Qt::Horizontal, tr("E-mail"));
    model->setHeaderData(4, Qt::Horizontal, tr("Site"));
    model->setHeaderData(5, Qt::Horizontal, tr("Endereço"));
    model->setHeaderData(6, Qt::Horizontal, tr("Contato"));
    model->setSort(2, Qt::DescendingOrder);
    model->select();

    ui->tvConsulta->setModel(model);

    ui->tvConsulta->setColumnHidden(4,true);
    ui->tvConsulta->setColumnHidden(5,true);

    ui->tvConsulta->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Stretch);

    ui->tvConsulta->resizeColumnsToContents();

    ui->leParametro->clear();
    ui->leParametro->setFocus();
}

void fornecedores::buscar()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QString filtro;
    filtro.append(""+_cbCampo.value(ui->cbCampo->currentText())+" like '"+ui->leParametro->text()+"%'");

    QSqlTableModel *model = new QSqlTableModel(this, con);
    model->setTable("fornecedores");
    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, tr("Fornecedor"));
    model->setHeaderData(2, Qt::Horizontal, tr("Telefone"));
    model->setHeaderData(3, Qt::Horizontal, tr("E-mail"));
    model->setHeaderData(4, Qt::Horizontal, tr("Site"));
    model->setHeaderData(5, Qt::Horizontal, tr("Endereço"));
    model->setHeaderData(6, Qt::Horizontal, tr("Contato"));
    model->setFilter(filtro);
    model->setSort(2, Qt::DescendingOrder);
    model->select();

    ui->tvConsulta->setModel(model);

    ui->tvConsulta->setColumnHidden(4,true);
    ui->tvConsulta->setColumnHidden(5,true);

    ui->tvConsulta->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Stretch);

    ui->tvConsulta->resizeColumnsToContents();
}

void fornecedores::on_pbAtualizar_clicked()
{
    atualizar_db();
}
