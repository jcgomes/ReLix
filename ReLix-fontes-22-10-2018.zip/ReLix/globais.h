#ifndef GLOBAIS_H
#define GLOBAIS_H
// globais.h é onde armazenamos as variáveis globais do projeto
#include <string>
#include <QString>

extern int _ID;                             // Recupera o id do registro. id = 0 (insere), id <=1 (atualiza)
extern int _IDcen;                          // Recupera o id do cenário. id = 0 (insere), id <=1 (atualiza)
extern int _IDtec;
extern int _IDitem;                         // Recupera o id ítem do cenário. id = 0 (insere), id <=1 (atualiza)
extern QString _DB;                         // banco de dados
extern QHash<QString,QString> _cbCampo;     // QHash é mais rápido que o QMap. http://doc.qt.io/qt-5/qhash.html

//TODO: converter a QHash acima para QMap para poder ordenar os lixões. A QHash ordena aleatoriamente.

#endif // GLOBAL_H
