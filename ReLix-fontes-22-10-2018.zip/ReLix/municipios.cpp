#include "municipios.h"
#include "ui_municipios.h"
#include "municipios_cad.h"
#include "globais.h"
#include <QtSql>
#include <QHash>
#include <QDesktopWidget>
#include <QMessageBox>
#include <QPainter>

#include <iostream>
using namespace std;

municipios::municipios(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::municipios)
{
    ui->setupUi(this);

    ui->tvConsulta->setItemDelegate(new delega_orcamento_disponivel);
    ui->pbAtualizar->setVisible(false);

    _cbCampo.clear();

    // Combobox dinâmico: http://www.qtcentre.org/threads/63124-Qcombobox-dinamically
    _cbCampo["ID"] = "municipios.id";
    _cbCampo["Município"] = "municipios.municipio";
    _cbCampo["UF"] = "municipios.uf";

    atualizar_db();
}

municipios::~municipios()
{
    delete ui;
}

void delega_orcamento_disponivel::paint(QPainter *painter, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const
{

    if (index.column() == 4) // coluna que será pintada
    {
        QString od = index.data().toString();
        int orcamentoDisponivel = od.replace(".","").replace(",","").toInt();

        if (orcamentoDisponivel < 0) // caso o valor do orçamento disponível seja negativo, pinta de vermelho
            painter->fillRect(option.rect, QColor(255, 40, 0));
    }

    return QItemDelegate::paint(painter, option, index);

}


void municipios::on_tvConsulta_doubleClicked(const QModelIndex &index)
{
    //http://www.qtcentre.org/threads/38184-QAbstractItemModel-double-click-on-current-row
    QItemSelectionModel *model = ui->tvConsulta->selectionModel();
    QModelIndex current = model->currentIndex().sibling(model->currentIndex().row(),0);
    QModelIndexList selected = model->selectedIndexes();

    _ID = current.data().toInt();

    municipios_cad *cad = new municipios_cad(this);
    cad->show();
}

void municipios::on_leParametro_returnPressed()
{
    _ID = ui->tvConsulta->model()->index(0,0).data().toInt();

    municipios_cad *cad = new municipios_cad(this);
    Qt::WindowFlags flags = windowFlags(); // http://stackoverflow.com/questions/19097323/setwindowflagsqtwindowstaysontophint-hides-qt-window
    cad->setWindowFlags(flags | Qt::WindowStaysOnTopHint);
    cad->setGeometry(QStyle::alignedRect(Qt::LeftToRight,Qt::AlignCenter, cad->size(), qApp->desktop()->availableGeometry())); // centraliza
    cad->show();
}

void municipios::on_leParametro_textChanged(const QString &arg1)
{
    buscar();
}

void municipios::on_pbAdicionar_clicked()
{
    _ID = 0;
    municipios_cad *cad = new municipios_cad(this);
    cad->show();
}

void municipios::on_pbSair_clicked()
{
    close();
}

void municipios::atualizar_db()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    // atualiza o orçamento disponível [início]
    QSqlQuery query;
    query.prepare("SELECT * FROM municipios");
    query.exec();
    query.first();

    while (query.next())
    {
        QString oi = query.value("orcamento_inicial").toString();
        int orcamentoInicial = oi.replace(".","").replace(",","").toInt();

        QSqlQuery query1;
        query1.prepare("SELECT "
                        "municipios.id AS municipios_id,"
                        "municipios.orcamento_inicial AS orcamento_inicial,"
                        "lixoes.id AS lixoes_id,"
                        "lixoes.id_municipio AS lixoes_id_municipio,"
                        "lixoes_cenarios.id_lixao AS lixoes_cenarios_id_lixao,"
                        "lixoes_cenarios.valor AS lixoes_cenarios_valor_cenario "
                      "FROM "
                        "municipios "
                        "LEFT JOIN lixoes ON municipios.id = lixoes.id_municipio "
                        "LEFT JOIN lixoes_cenarios ON lixoes.id = lixoes_cenarios.id_lixao "
                        "WHERE municipios.id=?");
        query1.bindValue(0,query.value("id"));
        query1.exec();
        query1.first();

        int soma = 0; // soma = soma dos valores totais dos cenários de cada lixão do município/região
        while (query1.next())
        {
            QString somaMunicipio = query1.value(5).toString();
            soma = soma + somaMunicipio.replace(".","").replace(",","").toInt();;
        }

        int orcamentoDisponivel = orcamentoInicial - soma;

        // Converter para o formato brasileiro
        QLocale loc = QLocale::system();
        QLocale brasil(QLocale::Portuguese);
        loc.setNumberOptions(brasil.numberOptions());
        QLocale::setDefault(loc);

        //cout << orcamentoDisponivel;
        //cout << brasil.toString(orcamentoDisponivel * 0.01, 'f', 2).toStdString();

        QSqlQuery query2;
        query2.prepare("UPDATE municipios set orcamento_disponivel=? WHERE id=?");
        query2.bindValue(0, brasil.toString(orcamentoDisponivel * 0.01, 'f', 2));
        query2.bindValue(1,query.value("id"));
        query2.exec();
    }
    // atualiza o orçamento disponível [fim]


    // atualiza o tableview [início]
    ui->cbCampo->clear();

    QHashIterator<QString, QString> i(_cbCampo);
    while (i.hasNext()) {
        i.next();
        ui->cbCampo->addItem(i.key());
    }

    ui->cbCampo->setCurrentText("Município");

    QSqlTableModel *model = new QSqlTableModel(this, con);
    model->setTable("municipios");
    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, tr("Município/Região"));
    model->setHeaderData(2, Qt::Horizontal, tr("UF"));
    model->setHeaderData(3, Qt::Horizontal, tr("Orçamento inicial"));
    model->setHeaderData(4, Qt::Horizontal, tr("Orçamento disponível"));
    model->select();

    ui->tvConsulta->setModel(model);
    ui->tvConsulta->setColumnHidden(3,true);
    ui->tvConsulta->setColumnHidden(4,true);
    //ui->tvConsulta->resizeColumnsToContents();

    ui->tvConsulta->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Stretch);

    ui->leParametro->clear();
    ui->leParametro->setFocus();
    // atualiza o tableview [fim]
}

void municipios::buscar()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QString filtro;
    filtro.append(""+_cbCampo.value(ui->cbCampo->currentText())+" like '"+ui->leParametro->text()+"%'");

    QSqlTableModel *model = new QSqlTableModel(this, con);
    model->setTable("municipios");
    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, tr("Município/Região"));
    model->setHeaderData(2, Qt::Horizontal, tr("UF"));
    model->setHeaderData(3, Qt::Horizontal, tr("Orçamento inicial"));
    model->setHeaderData(4, Qt::Horizontal, tr("Orçamento disponível"));
    model->setFilter(filtro);
    model->setSort(2, Qt::DescendingOrder);
    model->select();

    ui->tvConsulta->setModel(model);
    ui->tvConsulta->setColumnHidden(3,true);
    ui->tvConsulta->setColumnHidden(4,true);

    ui->tvConsulta->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Stretch);
}

void municipios::on_pbAtualizar_clicked()
{
    atualizar_db();
}
