#include "lixoes.h"
#include "ui_lixoes.h"
#include "lixoes_cad.h"
#include "lixoes_cen.h"
#include "globais.h"
#include <QtSql>
#include <QDesktopWidget>
#include <QPainter>
#include <QMessageBox>

# include <iostream>
using namespace std;

lixoes::lixoes(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::lixoes)
{
    ui->setupUi(this);

    ui->pbAtualizar->setVisible(false);

    _cbCampo.clear();

    // Combobox dinâmico: http://www.qtcentre.org/threads/63124-Qcombobox-dinamically
    _cbCampo["ID"] = "lixoes.id";
    _cbCampo["Nome do lixão"] = "lixoes.nome";
    _cbCampo["Município / região"] = "municipio";
    _cbCampo["Pontuação"] = "lixoes.pontuacao";
    _cbCampo["Nível de impacto"] = "lixoes.nivel_impacto";

    ui->tvConsulta->setItemDelegate(new Delegate);

    atualizar_db();
}

lixoes::~lixoes()
{
    delete ui;
}

void Delegate::paint(QPainter *painter, const QStyleOptionViewItem &option,
                          const QModelIndex &index) const
{
  /*
    if (index.column() == 101) // coluna que será pintada
    {
        //QVariant GetValueOfColumn =  index.model()->data(index.model()->index(index.row(),index.column()),Qt::DisplayRole);
        //http://www.qtcentre.org/threads/64391-SOLVED-Get-QModelIndex-data?p=284569#post284569
        QVariant GetValueOfColumn = index.data();

        if (GetValueOfColumn == "Reduzido")
            painter->fillRect(option.rect, QColor(170, 216, 0));
        if (GetValueOfColumn == "Baixo")
            painter->fillRect(option.rect, QColor(254, 251, 24));
        else if (GetValueOfColumn == "Médio")
            painter->fillRect(option.rect, QColor(255, 130, 0));
        else if (GetValueOfColumn == "Alto")
            painter->fillRect(option.rect, QColor(255, 40, 0));
    }

    */
    return QItemDelegate::paint(painter, option, index);

}

void lixoes::on_tvConsulta_doubleClicked(const QModelIndex &index)
{
    //http://www.qtcentre.org/threads/38184-QAbstractItemModel-double-click-on-current-row
    QItemSelectionModel *model = ui->tvConsulta->selectionModel();
    QModelIndex current = model->currentIndex().sibling(model->currentIndex().row(),0);
    QModelIndexList selected = model->selectedIndexes();

    _ID = current.data().toInt();

    lixoes_cad *cad = new lixoes_cad(this);
    cad->show();
}

void lixoes::on_leParametro_returnPressed()
{
    _ID = ui->tvConsulta->model()->index(0,0).data().toInt();

    lixoes_cad *cad = new lixoes_cad(this);
    cad->show();
}

void lixoes::on_leParametro_textChanged(const QString &arg1)
{
    buscar();
}

void lixoes::on_pbAtualizar_clicked()
{
    atualizar_db();
}

void lixoes::on_pbAdicionar_clicked()
{
    _ID = 0;
    lixoes_cad *cad = new lixoes_cad(this);
    cad->show();
}

void lixoes::on_pbSair_clicked()
{
    close();
}

void lixoes::atualizar_db()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    /*
    QSqlQuery query;
    query.prepare("SELECT * FROM lixoes");
    query.exec();


    while (query.next())
    {
        // atualiza o campo "valor_cenario" e "cenario" de todos os lixões [início]
        QSqlQuery query1;
        query1.prepare("SELECT valor FROM lixoes_cenarios WHERE id_lixao=?");
        query1.bindValue(0,query.value(0));
        query1.exec();

        int soma = 0;
        while (query1.next())
        {
            QString vt = query1.value(0).toString();
            int valot_total = vt.replace(".","").replace(",","").toInt();
            soma = soma + valot_total;
        }

        QLocale loc = QLocale::system();
        QLocale brasil(QLocale::Portuguese);
        loc.setNumberOptions(brasil.numberOptions());
        QLocale::setDefault(loc);


        //QSqlQuery query2;
        //query2.prepare("SELECT "
        //               "    lixoes_cenarios_itens.id AS lixoes_cenarios_itens_id, "
        //               "    lixoes_cenarios_itens.disponibilidade AS lixoes_cenarios_itens_disponibilidade "
        //               "FROM "
        //               "    lixoes "
        //               "LEFT JOIN lixoes_cenarios ON lixoes.id = lixoes_cenarios.id_lixao  "
        //               "LEFT JOIN lixoes_cenarios_itens ON lixoes_cenarios.id = lixoes_cenarios_itens.id_cenario "
        //               "WHERE lixoes_cenarios_itens_disponibilidade NOT NULL "
        //               "AND lixoes.id = ? "
        //                "ORDER BY lixoes_cenarios_itens.id asc");
        //query2.bindValue(0,query.value(0).toInt());
        //query2.exec();

        //int numReg = 0;
        //int disp = 0;
        //QString percent = "";
        //while (query2.next())
        //{
        //    numReg = numReg+1;

        //    if (query2.value(1).toString()=="Disponível")
        //        disp = disp+1;

        //    percent = QString::number((disp*100)/numReg) + "%"; //percentual de disponibilidade de recursos e serviços para os itens do cenário / ações do lixão
        //}


        QSqlQuery query3;
        query3.prepare("UPDATE lixoes SET valor_cenario=? WHERE id=?"); // valor_cenario = somatório dos valores de todos os cenários/ações do lixão
        query3.bindValue(0,brasil.toString(soma * 0.01, 'f', 2));
        //query3.bindValue(1,percent);
        query3.bindValue(1,query.value(0).toInt());
        query3.exec();
        // atualiza o campo "valor_cenario" e "disponibilidade_produtos_servicos" de todos os lixões [fim]
    }
    */

    // atualiza o tableview
    ui->cbCampo->clear();

    QHashIterator<QString, QString> i(_cbCampo);
    while (i.hasNext()) {
        i.next();
        ui->cbCampo->addItem(i.key());
    }

    ui->cbCampo->setCurrentIndex(0);

    // http://doc.qt.io/qt-5/qsqlrelationaltablemodel.html
    QSqlRelationalTableModel *model = new QSqlRelationalTableModel(this, con);
    model->setTable("lixoes");
    model->setJoinMode(QSqlRelationalTableModel::LeftJoin);
    model->setRelation(5, QSqlRelation("municipios", "id", "municipio"));
    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, tr("Nome do lixão"));
    model->setHeaderData(5, Qt::Horizontal, tr("Município / região"));
    model->setHeaderData(106, Qt::Horizontal, tr("Pontuação"));
    model->setHeaderData(107, Qt::Horizontal, tr("Nível de impacto"));
    model->select();

    ui->tvConsulta->setModel(model);
    ui->tvConsulta->sortByColumn(106, Qt::DescendingOrder); // order by pontuacao desc
    ui->tvConsulta->resizeColumnsToContents();

    ui->tvConsulta->setColumnHidden(2,true);
    ui->tvConsulta->setColumnHidden(3,true);
    ui->tvConsulta->setColumnHidden(4,true);
    for (int j=6;j<=105;j++)
        ui->tvConsulta->setColumnHidden(j,true);
    ui->tvConsulta->setColumnHidden(108,true);
    ui->tvConsulta->setColumnHidden(109,true);

    ui->tvConsulta->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Stretch);

    ui->leParametro->clear();
    ui->leParametro->setFocus();
}

void lixoes::buscar()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QString filtro;
    filtro.append(""+_cbCampo.value(ui->cbCampo->currentText())+" like '"+ui->leParametro->text()+"%'");

    // http://doc.qt.io/qt-5/qsqlrelationaltablemodel.html
    QSqlRelationalTableModel *model = new QSqlRelationalTableModel(this, con);
    model->setTable("lixoes");
    model->setJoinMode(QSqlRelationalTableModel::LeftJoin);
    model->setRelation(5, QSqlRelation("municipios", "id", "municipio"));
    model->setHeaderData(0, Qt::Horizontal, tr("ID"));
    model->setHeaderData(1, Qt::Horizontal, tr("Nome do lixão"));
    model->setHeaderData(5, Qt::Horizontal, tr("Município / região"));
    model->setHeaderData(106, Qt::Horizontal, tr("Pontuação"));
    model->setHeaderData(107, Qt::Horizontal, tr("Nível de impacto"));
    model->setFilter(filtro);
    model->select();

    ui->tvConsulta->setModel(model);
    ui->tvConsulta->sortByColumn(106, Qt::DescendingOrder); // order by pontuacao desc
    ui->tvConsulta->resizeColumnsToContents();
    ui->tvConsulta->setColumnHidden(2,true);
    ui->tvConsulta->setColumnHidden(3,true);
    ui->tvConsulta->setColumnHidden(4,true);
    for (int j=6;j<=105;j++)
        ui->tvConsulta->setColumnHidden(j,true);
    ui->tvConsulta->setColumnHidden(108,true);
    ui->tvConsulta->setColumnHidden(109,true);

    ui->tvConsulta->horizontalHeader()->setSectionResizeMode(1,QHeaderView::Stretch);
}
