#ifndef LIXOES_CEN_CAD_H
#define LIXOES_CEN_CAD_H

#include <QDialog>

namespace Ui {
class lixoes_cen_cad;
}

class lixoes_cen_cad : public QDialog
{
    Q_OBJECT

public:
    explicit lixoes_cen_cad(QWidget *parent = 0);
    ~lixoes_cen_cad();

private slots:
    void on_pbSalvar_clicked();

    void on_pbCancelar_clicked();

    void recuperar_registro();

    void inserir();

    void editar();

    void calcular_valorTotal();

    void on_leQuantidade_textChanged(const QString &arg1);

    void on_leValorUnitario_textChanged(const QString &arg1);

private:
    Ui::lixoes_cen_cad *ui;
};

#endif // LIXOES_CEN_CAD_H
