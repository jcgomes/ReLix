#ifndef LIXOES_CEN_H
#define LIXOES_CEN_H

#include <QDialog>
#include <QItemDelegate>

namespace Ui {
class lixoes_cen;
}

class lixoes_cen : public QDialog
{
    Q_OBJECT

public:
    explicit lixoes_cen(QWidget *parent = 0);
    ~lixoes_cen();

public slots:
    void atualizar_tvItens();

private slots:
    void on_pbSalvar_clicked();

    void on_pbCancelar_clicked();

    void on_pbAdicionar_clicked();

    void on_pbRemover_clicked();

    void recuperar_registro();

    void on_tvItens_clicked(const QModelIndex &index);

    void on_tvItens_doubleClicked(const QModelIndex &index);

    void inserir();

    void editar();

private:
    Ui::lixoes_cen *ui;
};
class delega_disponibilidade : public QItemDelegate
{
    Q_OBJECT
public:
    delega_disponibilidade(QWidget *parent = 0) : QItemDelegate(parent) {}
    void paint(QPainter *painter, const QStyleOptionViewItem &option,
               const QModelIndex &index) const;
};

#endif // LIXOES_CEN_H
