#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "municipios.h"
#include "lixoes.h"
#include "sobre.h"
#include "fornecedores.h"
#include <QMessageBox>
#include <QDir>
#include <QUrl>
#include <QDesktopServices>

# include <QDebug>

# include <iostream>
using namespace std;

// Variáveis Globais
int _ID = 0;
int _IDtec = 0;

QString _DB;
QHash<QString,QString> _cbCampo;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //this->setStyleSheet("QMainWindow {background: 'gray';}");
    this->showMaximized();

    _DB = QDir::toNativeSeparators(qApp->applicationDirPath()+"/db.db"); // caminho do bando de dados
    //_DB = "C:\relix\db.db";
    //qDebug() << qApp->applicationDirPath();
    //qDebug() << QDir::toNativeSeparators(qApp->applicationDirPath());
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_action_sair_triggered()
{
    close();
}

void MainWindow::on_action_municipios_triggered()
{
    municipios *mun = new municipios(this);
    mun->show();
}

void MainWindow::on_action_sobre_sistema_triggered()
{
    sobre *about = new sobre(this);
    about->show();
}

void MainWindow::on_action_formCampo_triggered()
{
    QString s = qApp->applicationDirPath() + QDir::toNativeSeparators("/doc/frmCampo.pdf");
    QDesktopServices::openUrl(QUrl::fromLocalFile(s));
}

void MainWindow::on_action_manual_triggered()
{
    QString s = qApp->applicationDirPath() + QDir::toNativeSeparators("/doc/manual.pdf");
    QDesktopServices::openUrl(QUrl::fromLocalFile(s));
}

void MainWindow::on_action_diagnostico_triggered()
{
    lixoes *li = new lixoes(this);
    li->show();
}

void MainWindow::on_action_fornecedores_triggered()
{
    fornecedores *forn = new fornecedores(this);
    forn->show();
}
