﻿#include "municipios_cad.h"
#include "ui_municipios_cad.h"
#include "globais.h"
#include <QHash>
#include <QMessageBox>
#include <QtSql>

#include <typeinfo>
#include <iostream>
#include "municipios.h"

using namespace std;

QMap<QString,int> _cbUF; // QMap ordena a lista por key. http://doc.qt.io/qt-5/qmap.html

municipios_cad::municipios_cad(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::municipios_cad)
{
    ui->setupUi(this);

    // http://pt.stackoverflow.com/questions/179480/ajuda-com-signal-and-slots-conectar-em-slot-de-outro-arquivo
    connect(ui->pbSalvar, &QPushButton::clicked, static_cast<municipios*>(parent), &municipios::atualizar_db);

    // Format of Real: Brazilian Money
    // http://www.qtforum.org/article/31994/ideas-use-lineedit-with-mask-or-validator-for-money-input.html
    QRegExp valid("^\\d{1,3}(([.]\\d{3})*),(\\d{2})$"); // "^\\d{1,3}(([.]\\d{3})*),(\\d{2})$" = 000.000,00
    ui->leOrcamentoInicial->setValidator(new QRegExpValidator(valid, ui->leOrcamentoInicial));
    ui->leOrcamentoInicial->setVisible(false);
    ui->lbOrcamentoInicial->setVisible(false);

    _cbUF.insert("AC", 0);
    _cbUF.insert("AL", 1);
    _cbUF.insert("AM", 2);
    _cbUF.insert("AP", 3);
    _cbUF.insert("BA", 4);
    _cbUF.insert("CE", 5);
    _cbUF.insert("DF", 6);
    _cbUF.insert("ES", 7);
    _cbUF.insert("GO", 8);
    _cbUF.insert("MA", 9);
    _cbUF.insert("MG", 10);
    _cbUF.insert("MS", 11);
    _cbUF.insert("MT", 12);
    _cbUF.insert("PA", 13);
    _cbUF.insert("PB", 14);
    _cbUF.insert("PE", 15);
    _cbUF.insert("PI", 16);
    _cbUF.insert("PR", 17);
    _cbUF.insert("RJ", 18);
    _cbUF.insert("RN", 19);
    _cbUF.insert("RO", 20);
    _cbUF.insert("RR", 21);
    _cbUF.insert("RS", 22);
    _cbUF.insert("SC", 23);
    _cbUF.insert("SE", 24);
    _cbUF.insert("SP", 25);
    _cbUF.insert("TO", 26);

    QMapIterator<QString, int> i(_cbUF);
    while (i.hasNext()) {
        i.next();
        ui->cbUF->addItem(i.key());
    }

    if (_ID == 0)
        ui->leMunicipio->setFocus();
    else
        recuperar_registro();
}

municipios_cad::~municipios_cad()
{
    delete ui;
}

void municipios_cad::on_pbSalvar_clicked()
{
    if (_ID == 0)
        inserir();
    else
        editar();


    municipios m;
    m.atualizar_db();
}

void municipios_cad::on_pbCancelar_clicked()
{
    close();
}

void municipios_cad::recuperar_registro()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("SELECT * FROM municipios where id = ? ");
    query.bindValue(0,_ID);
    query.exec();

    while (query.next())
    {
        ui->leMunicipio->setText(query.value(1).toString());

        QMapIterator<QString, int> i(_cbUF);
        while (i.hasNext()) {
            i.next();
            if (query.value(2).toString() == i.key())
                ui->cbUF->setCurrentIndex(i.value());
        }

        ui->leOrcamentoInicial->setText(query.value(3).toString());
    }

    con.close();
}

void municipios_cad::inserir()
{

    // insere
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlTableModel *model = new QSqlTableModel(this, con);
    model->setTable("municipios");
    model->select();

    QSqlRecord rec = model->record();
    rec.setValue("municipio", ui->leMunicipio->text());
    rec.setValue("uf", ui->cbUF->currentText());
    rec.setValue("orcamento_inicial", ui->leOrcamentoInicial->text());
    model->insertRecord(-1,rec);

    con.close();

    QMessageBox msgBox;
    msgBox.setText("Informações inseridas com sucesso");
    msgBox.exec();

    close();

}

void municipios_cad::editar()
{
    // atualiza
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    /* Trabalhando com valoes monetários brasileiros:
     * 1) Campo da tabela no formato TEXT
     * 2) Para armazenar inicialmente os dados na tabela, usar um QRegExpValidator, conforme na inicialização do formulário
     * 3) Ao recuperar os valores da tabela, converter para o formato int (para ter valores precisos)
     * 4) Fazer as operações matemáticas (OMs) no formato int
     * 5) Salvar os vaores das OMs na tabela, convertendo novamente para o formato brasileiro, usando um QLocale
     * Detalhes aqui: http://pt.stackoverflow.com/questions/10038/convers%C3%A3o-de-n%C3%BAmero-inteiro-para-pre%C3%A7o-usando-qlocate
     */

    // A Cada edição realizada, re-calcular o orçamento disponível

    QString oi = ui->leOrcamentoInicial->text();
    int orcamentoInicial = oi.replace(".","").replace(",","").toInt();

    QSqlQuery query1;
    query1.prepare("SELECT "
                    "municipios.id AS municipios_id,"
                    "municipios.orcamento_inicial AS orcamento_inicial,"
                    "lixoes.id AS lixoes_id,"
                    "lixoes.id_municipio AS lixoes_id_municipio,"
                    "lixoes_cenarios.id_lixao AS lixoes_cenarios_id_lixao,"
                    "lixoes_cenarios.valor AS lixoes_cenarios_valor_cenario "
                  "FROM "
                    "municipios "
                    "LEFT JOIN lixoes ON municipios.id = lixoes.id_municipio "
                    "LEFT JOIN lixoes_cenarios ON lixoes.id = lixoes_cenarios.id_lixao "
                    "WHERE municipios.id=?");
    query1.bindValue(0,_ID);
    query1.exec();
    query1.first();

    int soma = 0; // soma = soma dos valores totais dos cenários de cada lixão do município/região
    while (query1.next())
    {
        QString somaMunicipio = query1.value(5).toString();
        soma = soma + somaMunicipio.replace(".","").replace(",","").toInt();;
    }

    int orcamentoDisponivel = orcamentoInicial - soma;

    // Converter para o formato brasileiro
    QLocale loc = QLocale::system();
    QLocale brasil(QLocale::Portuguese);
    loc.setNumberOptions(brasil.numberOptions());
    QLocale::setDefault(loc);

    QSqlQuery query2;
    query2.prepare("UPDATE municipios set municipio=?, uf=?, orcamento_inicial=?, orcamento_disponivel=? WHERE id=?");
    query2.bindValue(0, ui->leMunicipio->text());
    query2.bindValue(1, ui->cbUF->currentText());
    query2.bindValue(2, ui->leOrcamentoInicial->text());
    query2.bindValue(3, brasil.toString(orcamentoDisponivel * 0.01, 'f', 2));
    query2.bindValue(4,_ID);
    query2.exec();

    con.close();

    QMessageBox msgBox;
    msgBox.setText("Informações atualizadas com sucesso");
    msgBox.exec();

    close();
}
