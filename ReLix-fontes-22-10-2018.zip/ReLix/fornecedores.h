#ifndef FORNECEDORES_H
#define FORNECEDORES_H

#include <QDialog>

namespace Ui {
class fornecedores;
}

class fornecedores : public QDialog
{
    Q_OBJECT

public:
    explicit fornecedores(QWidget *parent = 0);
    ~fornecedores();

public slots:
    void atualizar_db();

private slots:
    void on_tvConsulta_doubleClicked(const QModelIndex &index);

    void on_leParametro_returnPressed();

    void on_leParametro_textChanged(const QString &arg1);

    void on_pbAdicionar_clicked();

    void on_pbSair_clicked();

    void buscar();

    void on_pbAtualizar_clicked();

private:
    Ui::fornecedores *ui;
};

#endif // FORNECEDORES_H
