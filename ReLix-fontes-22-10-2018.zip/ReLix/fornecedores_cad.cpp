#include "fornecedores_cad.h"
#include "ui_fornecedores_cad.h"
#include "globais.h"
#include <QHash>
#include <QMessageBox>
#include <QtSql>
#include "fornecedores.h"

fornecedores_cad::fornecedores_cad(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::fornecedores_cad)
{
    ui->setupUi(this);

    // http://pt.stackoverflow.com/questions/179480/ajuda-com-signal-and-slots-conectar-em-slot-de-outro-arquivo
    connect(ui->pbSalvar, &QPushButton::clicked, static_cast<fornecedores*>(parent), &fornecedores::atualizar_db);

    if (_ID == 0)
        ui->leFornecedor->setFocus();
    else
        recuperar_registro();
}

fornecedores_cad::~fornecedores_cad()
{
    delete ui;
}

void fornecedores_cad::on_pbSalvar_clicked()
{
    if (_ID == 0)
        inserir();
    else
        editar();
}

void fornecedores_cad::on_pbCancelar_clicked()
{
    close();
}

void fornecedores_cad::recuperar_registro()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("SELECT * FROM fornecedores where id = ? ");
    query.bindValue(0,_ID);
    query.exec();

    while (query.next())
    {
        ui->leFornecedor->setText(query.value(1).toString());
        ui->leTelefone->setText(query.value(2).toString());
        ui->leEmail->setText(query.value(3).toString());
        ui->leSite->setText(query.value(4).toString());
        ui->leEndereco->setText(query.value(5).toString());
        ui->leContato->setText(query.value(6).toString());
    }

    con.close();
}

void fornecedores_cad::inserir()
{
    // insere
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlTableModel *model = new QSqlTableModel(this, con);
    model->setTable("fornecedores");
    model->select();

    QSqlRecord rec = model->record();
    rec.setValue("fornecedor", ui->leFornecedor->text());
    rec.setValue("telefone", ui->leTelefone->text());
    rec.setValue("email", ui->leEmail->text());
    rec.setValue("site", ui->leSite->text());
    rec.setValue("endereco", ui->leEndereco->text());
    rec.setValue("contato", ui->leContato->text());

    model->insertRecord(-1,rec);

    con.close();

    QMessageBox msgBox;
    msgBox.setText("Informações inseridas com sucesso");
    msgBox.exec();

    close();
}

void fornecedores_cad::editar()
{
    // atualiza
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query2;
    query2.prepare("UPDATE fornecedores set fornecedor=?, telefone=?, email=?, site=?, endereco=?, contato=? WHERE id=?");
    query2.bindValue(0, ui->leFornecedor->text());
    query2.bindValue(1, ui->leTelefone->text());
    query2.bindValue(2, ui->leEmail->text());
    query2.bindValue(3, ui->leSite->text());
    query2.bindValue(4, ui->leEndereco->text());
    query2.bindValue(5, ui->leContato->text());
    query2.bindValue(6,_ID);
    query2.exec();

    con.close();

    QMessageBox msgBox;
    msgBox.setText("Informações atualizadas com sucesso");
    msgBox.exec();

    close();

}
