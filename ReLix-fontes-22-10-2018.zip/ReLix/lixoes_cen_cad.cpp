#include "lixoes_cen_cad.h"
#include "ui_lixoes_cen_cad.h"
#include "globais.h"
#include <QMessageBox>
#include <QtSql>
#include "lixoes_cen.h"
#include "lixoes_cad.h"

#include <typeinfo>
# include <iostream>
using namespace std;

lixoes_cen_cad::lixoes_cen_cad(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::lixoes_cen_cad)
{
    ui->setupUi(this);

    // http://pt.stackoverflow.com/questions/179480/ajuda-com-signal-and-slots-conectar-em-slot-de-outro-arquivo
    //connect(ui->pbSalvar, &QPushButton::clicked, static_cast<lixoes_cen*>(parent), &lixoes_cen::atualizar_tvItens); // ao clicar no botão salvar
    connect(this, &QDialog::rejected, static_cast<lixoes_cen*>(parent), &lixoes_cen::atualizar_tvItens); // ao sair do formulario

    QRegExp valid("^\\d{1,3}(([.]\\d{3})*),(\\d{2})$"); // "^\\d{1,3}(([.]\\d{3})*),(\\d{2})$" = 000.000,00
    ui->leQuantidade->setValidator(new QRegExpValidator(valid, ui->leQuantidade));    
    ui->leValorUnitario->setValidator(new QRegExpValidator(valid, ui->leValorUnitario));
    ui->leValorTotal->setValidator(new QRegExpValidator(valid, ui->leValorTotal));

    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("SELECT * FROM fornecedores");
    query.exec();
    while (query.next())
    {
        QString s = query.value(1).toString();
        ui->cbFornecedor->addItem(s);
    }
    con.close();

    if (_IDitem == 0)
    {
        ui->leDescricao->setFocus();
    }
    else
    {
        recuperar_registro();
    }
}

lixoes_cen_cad::~lixoes_cen_cad()
{
    delete ui;
}

void lixoes_cen_cad::recuperar_registro()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("SELECT * FROM lixoes_cenarios_tecnicas_itens where id = ? ");
    query.bindValue(0,_IDitem);
    query.exec();
    query.first();

    ui->leDescricao->setText(query.value("descricao").toString());

    if (query.value("categoria").toString() == "Produto")
    {
        ui->rbCategoria_0->setChecked(true);
    }
    else if (query.value("categoria").toString() == "Serviço")
    {
        ui->rbCategoria_1->setChecked(true);
    }

    QSqlQuery query2;
    query2.prepare("SELECT * FROM fornecedores where id = ? ");
    query2.bindValue(0,query.value("id_fornecedor").toInt());
    query2.exec();
    while (query2.next())
    {
        int index = ui->cbFornecedor->findText(query2.value(1).toString());
        if( index >= 0 )
            ui->cbFornecedor->setCurrentIndex(index);
    }

    ui->leQuantidade->setText(query.value("quantidade").toString());
    ui->leUnidade->setText(query.value("unidade").toString());
    ui->leValorUnitario->setText(query.value("valor_unitario").toString());
    ui->leValorTotal->setText(query.value("valor_total").toString());

    if (query.value("disponibilidade").toString() == "Disponível")
    {
        ui->rbDisponibilidade_0->setChecked(true);
    }
    else if (query.value("disponibilidade").toString() == "Parcialmente disponível")
    {
        ui->rbDisponibilidade_1->setChecked(true);
    }
    else if (query.value("disponibilidade").toString() == "Indisponível")
    {
        ui->rbDisponibilidade_2->setChecked(true);
    }

    ui->leObs->setText(query.value("observacoes").toString());

    con.close();
}

void lixoes_cen_cad::inserir()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("INSERT INTO lixoes_cenarios_tecnicas_itens "
                  "(id_tecnica, "
                  "descricao, "
                  "categoria, "
                  "id_fornecedor, "
                  "quantidade, "
                  "unidade, "
                  "valor_unitario, "
                  "valor_total, "
                  "disponibilidade, "
                  "observacoes) "
                  "VALUES (?,?,?,?,?,?,?,?,?,?)");
    query.bindValue(0, _IDtec);
    query.bindValue(1, ui->leDescricao->text());

    if (ui->rbCategoria_0->isChecked())
        query.bindValue(2,"Produto");
    else if (ui->rbCategoria_1->isChecked())
        query.bindValue(2,"Serviço");

    QSqlQuery query2;
    query2.prepare("SELECT id, fornecedor FROM fornecedores where fornecedor = ? ");
    query2.bindValue(0,ui->cbFornecedor->currentText());
    query2.exec();
    query2.first();

    query.bindValue(3,query2.value(0));

    query.bindValue(4,ui->leQuantidade->text());
    query.bindValue(5,ui->leUnidade->text());
    query.bindValue(6,ui->leValorUnitario->text());
    query.bindValue(7,ui->leValorTotal->text());

    if (ui->rbDisponibilidade_0->isChecked())
        query.bindValue(8,"Disponível");
    else if (ui->rbDisponibilidade_1->isChecked())
        query.bindValue(8,"Parcialmente disponível");
    else if (ui->rbDisponibilidade_2->isChecked())
        query.bindValue(8,"Indisponível");

    query.bindValue(9,ui->leObs->text());

    query.exec();
    con.close();

    QMessageBox msgBox;
    msgBox.setText("Informações inseridas com sucesso");
    msgBox.exec();

    close();
}

void lixoes_cen_cad::editar()
{
    QSqlDatabase con = QSqlDatabase::addDatabase("QSQLITE");
    con.setDatabaseName(_DB);
    con.open();

    QSqlQuery query;
    query.prepare("UPDATE lixoes_cenarios_tecnicas_itens SET "
                  "id_tecnica=?, "
                  "descricao=?, "
                  "categoria=?, "
                  "id_fornecedor=?, "
                  "quantidade=?, "
                  "unidade=?, "
                  "valor_unitario=?, "
                  "valor_total=?, "
                  "disponibilidade=?, "
                  "observacoes=? "
                  "WHERE id=?");

    query.bindValue(0, _IDtec);
    query.bindValue(1, ui->leDescricao->text());

    if (ui->rbCategoria_0->isChecked())
        query.bindValue(2,"Produto");
    else if (ui->rbCategoria_1->isChecked())
        query.bindValue(2,"Serviço");

    QSqlQuery query2;
    query2.prepare("SELECT id, fornecedor FROM fornecedores where fornecedor = ? ");
    query2.bindValue(0,ui->cbFornecedor->currentText());
    query2.exec();
    query2.first();

    query.bindValue(3,query2.value(0));

    query.bindValue(4,ui->leQuantidade->text());
    query.bindValue(5,ui->leUnidade->text());
    query.bindValue(6,ui->leValorUnitario->text());
    query.bindValue(7,ui->leValorTotal->text());

    if (ui->rbDisponibilidade_0->isChecked())
        query.bindValue(8,"Disponível");
    else if (ui->rbDisponibilidade_1->isChecked())
        query.bindValue(8,"Parcialmente disponível");
    else if (ui->rbDisponibilidade_2->isChecked())
        query.bindValue(8,"Indisponível");

    query.bindValue(9,ui->leObs->text());

    query.bindValue(10,_IDitem);

    query.exec();
    con.close();

    QMessageBox msgBox;
    msgBox.setText("Informações atualizadas com sucesso");
    msgBox.exec();

    close();
}

void lixoes_cen_cad::on_pbSalvar_clicked()
{
    if (_IDitem == 0)
        inserir();
    else
        editar();
}

void lixoes_cen_cad::on_pbCancelar_clicked()
{
    close();
}

void lixoes_cen_cad::calcular_valorTotal()
{
    QString qtdade = ui->leQuantidade->text();
    QString vu = ui->leValorUnitario->text();

    int quantidade = qtdade.replace(".","").replace(",","").toInt();
    int valorUnitario = vu.replace(".","").replace(",","").toInt();

    int valorTotal = quantidade * valorUnitario;

    // Converter para o formato brasileiro
    QLocale loc = QLocale::system();
    QLocale brasil(QLocale::Portuguese);
    loc.setNumberOptions(brasil.numberOptions());
    QLocale::setDefault(loc);

    ui->leValorTotal->setText(brasil.toString(valorTotal * 0.01, 'f', 2));
}

void lixoes_cen_cad::on_leQuantidade_textChanged(const QString &arg1)
{
    calcular_valorTotal();
}

void lixoes_cen_cad::on_leValorUnitario_textChanged(const QString &arg1)
{
    calcular_valorTotal();
}
